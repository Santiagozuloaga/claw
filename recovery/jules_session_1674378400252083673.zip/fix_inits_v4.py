import os
from pathlib import Path

def fix_task_init():
    p = Path("01_SRC/2024-06-19_CLAW_TASK_V01/__init__.py")
    content = """\"\"\"Task system for clawspring.\"\"\"
import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_types = _import_iso(".types")
Task = _types.Task
TaskStatus = _types.TaskStatus

_store = _import_iso(".store")
create_task = _store.create_task
get_task = _store.get_task
list_tasks = _store.list_tasks
update_task = _store.update_task
delete_task = _store.delete_task
clear_all_tasks = _store.clear_all_tasks
reload_from_disk = _store.reload_from_disk

__all__ = [
    "Task", "TaskStatus",
    "create_task", "get_task", "list_tasks", "update_task",
    "delete_task", "clear_all_tasks", "reload_from_disk",
]
"""
    p.write_text(content, encoding='utf-8')

def fix_mcp_init():
    p = Path("01_SRC/2024-06-19_CLAW_MCP_V01/__init__.py")
    content = """import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_types = _import_iso(".types")
MCPServerConfig = _types.MCPServerConfig
MCPTool = _types.MCPTool
MCPServerState = _types.MCPServerState
MCPTransport = _types.MCPTransport
"""
    p.write_text(content, encoding='utf-8')

def fix_memory_init():
    p = Path("01_SRC/2024-06-19_CLAW_MEMORY_PACKAGE_V01/__init__.py")
    content = """import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_store = _import_iso(".store")
MemoryEntry = _store.MemoryEntry
"""
    p.write_text(content, encoding='utf-8')

def fix_skill_init():
    p = Path("01_SRC/2024-06-19_CLAW_SKILL_V01/__init__.py")
    content = """import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_loader = _import_iso(".loader")
SkillDef = _loader.SkillDef
"""
    p.write_text(content, encoding='utf-8')

def fix_multi_agent_init():
    p = Path("01_SRC/2024-06-19_CLAW_MULTI_AGENT_V01/__init__.py")
    content = """import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_sa = _import_iso(".subagent")
SubAgentManager = _sa.SubAgentManager
"""
    p.write_text(content, encoding='utf-8')

fix_task_init()
fix_mcp_init()
fix_memory_init()
fix_skill_init()
fix_multi_agent_init()
