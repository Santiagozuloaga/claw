import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_sa = _import_iso(".subagent")
SubAgentManager = _sa.SubAgentManager
