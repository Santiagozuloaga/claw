"""Backward-compatibility shim — real implementation is in memory/ package."""
import importlib
_m = importlib.import_module("2024-06-19_CLAW_MEMORY_PACKAGE_V01.store")
# noqa: F401
    MemoryEntry = _m.# noqa: F401
    MemoryEntry
save_memory = _m.save_memory
delete_memory = _m.delete_memory
load_index = _m.load_index
search_memory = _m.search_memory
get_index_content = _m.get_index_content
parse_frontmatter = _m.parse_frontmatter
import importlib
_m = importlib.import_module("2024-06-19_CLAW_MEMORY_PACKAGE_V01.context")
get_memory_context  # noqa: F401 = _m.get_memory_context  # noqa: F401
