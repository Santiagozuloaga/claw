"""Backward-compatibility shim — real implementation is in multi_agent/subagent.py."""
import importlib
_m = importlib.import_module("2024-06-19_CLAW_MULTI_AGENT_V01.subagent")
# noqa: F401
    AgentDefinition = _m.# noqa: F401
    AgentDefinition
SubAgentTask = _m.SubAgentTask
SubAgentManager = _m.SubAgentManager
load_agent_definitions = _m.load_agent_definitions
get_agent_definition = _m.get_agent_definition
_extract_final_text = _m._extract_final_text
_agent_run = _m._agent_run
_BUILTIN_AGENTS = _m._BUILTIN_AGENTS
