"""Context window management, automatic pruning/compaction."""
import importlib

def _import_iso(name):
    return importlib.import_module(name)

providers = _import_iso("2024-06-19_CLAW_PROVIDERS_V01")

def estimate_tokens(messages: list) -> int:
    """Rough estimation: 4 chars per token."""
    chars = sum(len(str(m.get("content", ""))) for m in messages)
    return chars // 4

def get_context_limit(model: str) -> int:
    """Return token limit for known models."""
    if "claude-3-5" in model: return 200000
    if "claude-3" in model:   return 200000
    if "gpt-4" in model:      return 128000
    if "gpt-3.5" in model:    return 16000
    return 32000  # Default for unknown models (e.g. local Ollama)

def maybe_compact(state, config):
    """
    Check if current session is approaching the model's context limit.
    If so, prune or summarize old messages.
    """
    model = config.get("model", "")
    limit = get_context_limit(model)
    threshold = int(limit * 0.8)  # Prune at 80% capacity
    
    current = estimate_tokens(state.messages)
    if current < threshold:
        return

    # ── Strategy 1: Remove old tool results (often large & low-value) ──
    snip_old_tool_results(state.messages)
    
    # Check again
    current = estimate_tokens(state.messages)
    if current < threshold:
        return

    # ── Strategy 2: Summarization or hard truncation ──
    # For this minimal implementation, we simply remove the middle of the history
    # keeping the system prompt (first msg if present) and most recent turns.
    if len(state.messages) > 10:
        # Keep first message and last 8
        state.messages = [state.messages[0]] + state.messages[-9:]


def snip_old_tool_results(messages: list):
    """Replace content of old 'tool' role messages with a short placeholder."""
    # We keep the last 4 tool results intact
    tool_count = 0
    for m in reversed(messages):
        if m.get("role") == "tool":
            tool_count += 1
            if tool_count > 4:
                m["content"] = "(old tool output snipped to save context)"

def find_split_point(messages: list, target_tokens: int) -> int:
    """Find index where last N messages fit within target_tokens."""
    total = 0
    for i in range(len(messages) - 1, -1, -1):
        total += len(str(messages[i].get("content", ""))) // 4
        if total > target_tokens:
            return i + 1
    return 0
