"""Backward-compatibility shim — real implementation is in skill/ package."""
import importlib
_m = importlib.import_module("2024-06-19_CLAW_SKILL_V01.loader")
# noqa: F401
    SkillDef = _m.# noqa: F401
    SkillDef
load_skills = _m.load_skills
find_skill = _m.find_skill
substitute_arguments = _m.substitute_arguments
_parse_skill_file = _m._parse_skill_file
_parse_list_field = _m._parse_list_field
import importlib
_m = importlib.import_module("2024-06-19_CLAW_SKILL_V01.executor")
execute_skill  # noqa: F401 = _m.execute_skill  # noqa: F401

# Legacy constant — kept for tests that patch it
import importlib
_m = importlib.import_module("2024-06-19_CLAW_SKILL_V01.loader")
_gsp = _m._get_skill_paths
SKILL_PATHS = _gsp()
