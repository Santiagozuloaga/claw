import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_loader = _import_iso(".loader")
SkillDef = _loader.SkillDef
load_skills = _loader.load_skills
