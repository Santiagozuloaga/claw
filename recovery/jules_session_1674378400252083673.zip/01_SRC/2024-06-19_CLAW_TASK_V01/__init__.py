"""Task system for clawspring."""
import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_types = _import_iso(".types")
Task = _types.Task
TaskStatus = _types.TaskStatus

_store = _import_iso(".store")
create_task = _store.create_task
get_task = _store.get_task
list_tasks = _store.list_tasks
update_task = _store.update_task
delete_task = _store.delete_task
clear_all_tasks = _store.clear_all_tasks
reload_from_disk = _store.reload_from_disk

__all__ = [
    "Task", "TaskStatus",
    "create_task", "get_task", "list_tasks", "update_task",
    "delete_task", "clear_all_tasks", "reload_from_disk",
]
