import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_store = _import_iso(".store")
MemoryEntry = _store.MemoryEntry
