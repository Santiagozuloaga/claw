"""Global environment and session context for ClawSpring."""
import os
import sys
import importlib
from pathlib import Path

def _import_iso(name):
    return importlib.import_module(name)

def build_system_prompt() -> str:
    """Build the final system prompt including runtime context (CWD, etc.)."""
    cwd = os.getcwd()
    try:
        shim = _import_iso("2024-06-19_CLAW_MEMORY_SHIM_V01")
        mem_ctx = shim.get_memory_context()
    except (ImportError, AttributeError):
        mem_ctx = ""

    # Personality injection
    try:
        from 2024_06_19_CLAW_PERSONALIDAD_V01 import SYSTEM_PROMPT as PERS_PROMPT
    except ImportError:
        # Fallback if personality file is not found or has different nomenclature
        try:
             pers = _import_iso("2024-06-19_CLAW_PERSONALIDAD_V01")
             PERS_PROMPT = pers.SYSTEM_PROMPT
        except:
             PERS_PROMPT = "You are Sage, a helpful AI assistant."

    prompt = f"""{PERS_PROMPT}

CURRENT CONTEXT:
- Working Directory: {cwd}
- Platform: {sys.platform}
- Python: {sys.version.split()[0]}

{mem_ctx}

INSTRUCTIONS:
1. Use the provided tools to explore the codebase and complete tasks.
2. If you need to edit a file, read it first to ensure you have the correct context.
3. Be concise and actionable.
4. When writing code, follow best practices and ensure it is correct.
"""
    return prompt
