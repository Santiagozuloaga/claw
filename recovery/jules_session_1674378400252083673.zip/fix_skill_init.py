import os
from pathlib import Path

p = Path("01_SRC/2024-06-19_CLAW_SKILL_V01/__init__.py")
content = """import importlib

def _import_iso(name):
    return importlib.import_module(name, __package__)

_loader = _import_iso(".loader")
SkillDef = _loader.SkillDef
load_skills = _loader.load_skills
"""
p.write_text(content, encoding='utf-8')
