import importlib
import pytest

_reg = importlib.import_module("2024-06-19_CLAW_TOOL_REGISTRY_V01")
ToolDef = _reg.ToolDef
register_tool = _reg.register_tool
get_tool = _reg.get_tool
get_all_tools = _reg.get_all_tools
get_tool_schemas = _reg.get_tool_schemas
execute_tool = _reg.execute_tool
clear_registry = _reg.clear_registry

def test_register_and_get():
    clear_registry()
    def my_tool(x: int): return str(x)
    td = ToolDef(
        name="MyTool",
        description="test",
        parameters={"type":"object", "properties":{"x":{"type":"integer"}}},
        handler=my_tool
    )
    register_tool(td)
    assert get_tool("MyTool") == td
    assert "MyTool" in get_all_tools()

def test_execute_tool():
    clear_registry()
    def add(a, b): return a + b
    register_tool(ToolDef("Add", "add", {}, add))
    res = execute_tool("Add", {"a":1, "b":2})
    assert res == 3

def test_get_schemas():
    clear_registry()
    register_tool(ToolDef("T1", "d1", {"p":1}, lambda:0))
    schemas = get_tool_schemas()
    assert len(schemas) == 1
    assert schemas[0]["name"] == "T1"
