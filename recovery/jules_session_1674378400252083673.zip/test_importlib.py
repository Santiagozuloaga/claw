import importlib
import sys
from pathlib import Path

sys.path.insert(0, "01_SRC")
try:
    mod = importlib.import_module("2024-06-19_CLAW_PROVIDERS_V01")
    print(f"Successfully imported {mod.__name__}")
    # Test package import
    pkg = importlib.import_module("2024-06-19_CLAW_MEMORY_PACKAGE_V01.context")
    print(f"Successfully imported {pkg.__name__}")
except Exception as e:
    print(f"Failed: {e}")
