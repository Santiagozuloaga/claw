import os
import re

def fix_file(filepath):
    if not filepath.endswith('.py'):
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    replacements = {
        'compaction': '2024-06-19_CLAW_COMPACTION_V01',
        'tool_registry': '2024-06-19_CLAW_TOOL_REGISTRY_V01',
        'providers': '2024-06-19_CLAW_PROVIDERS_V01',
        'config': '2024-06-19_CLAW_CONFIG_V01',
        'agent': '2024-06-19_CLAW_AGENT_V01',
        'memory_shim': '2024-06-19_CLAW_MEMORY_SHIM_V01',
        'mcp': '2024-06-19_CLAW_MCP_V01',
        'memory': '2024-06-19_CLAW_MEMORY_PACKAGE_V01',
        'multi_agent': '2024-06-19_CLAW_MULTI_AGENT_V01',
        'plugin': '2024-06-19_CLAW_PLUGIN_V01',
        'skill': '2024-06-19_CLAW_SKILL_V01',
        'task': '2024-06-19_CLAW_TASK_V01',
        'voice': '2024-06-19_CLAW_VOICE_V01',
        'encoding': '2024-06-19_CLAW_ENCODING_V01'
    }

    new_content = content

    # Systematic replacement for 'from MODULE[.SUB] import ...'
    for old, new in replacements.items():
        # Match 'from MODULE import AAA, BBB' (strictly single line for now to avoid mess)
        pattern = rf'^(\s*)from ({old}(\.[a-z0-9_]+)*) import ([^(\n]+)$'
        def replace_from(match):
            indent = match.group(1)
            full_module = match.group(2)
            sub = full_module[len(old):]
            target_module = new + sub
            items_str = match.group(4).strip()
            items = [item.strip() for item in items_str.split(',') if item.strip()]
            
            res = f'{indent}import importlib\n{indent}_m = importlib.import_module("{target_module}")'
            for item in items:
                if ' as ' in item:
                    orig, alias = item.split(' as ')
                    res += f'\n{indent}{alias.strip()} = _m.{orig.strip()}'
                else:
                    res += f'\n{indent}{item} = _m.{item}'
            return res
        new_content = re.sub(pattern, replace_from, new_content, flags=re.MULTILINE)

    # Handle 'import MODULE[.SUB] as ALIAS'
    for old, new in replacements.items():
        pattern = rf'^(\s*)import ({old}(\.[a-z0-9_]+)*) as ([a-z0-9_]+)$'
        def replace_import_as(match):
            indent = match.group(1)
            full_module = match.group(2)
            sub = full_module[len(old):]
            target_module = new + sub
            alias = match.group(4)
            return f'{indent}import importlib\n{indent}{alias} = importlib.import_module("{target_module}")'
        new_content = re.sub(pattern, replace_import_as, new_content, flags=re.MULTILINE)

    # Handle 'import MODULE[.SUB]'
    for old, new in replacements.items():
        pattern = rf'^(\s*)import ({old}(\.[a-z0-9_]+)*)$'
        def replace_import(match):
            indent = match.group(1)
            full_module = match.group(2)
            sub = full_module[len(old):]
            target_module = new + sub
            name = full_module.split('.')[-1]
            return f'{indent}import importlib\n{indent}{name} = importlib.import_module("{target_module}")'
        new_content = re.sub(pattern, replace_import, new_content, flags=re.MULTILINE)

    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Fixed {filepath}")

for root, dirs, files in os.walk('01_SRC'):
    for file in files:
        fix_file(os.path.join(root, file))

# We will skip automatic fixing for tests as they have complex imports
# for root, dirs, files in os.walk('02_TESTS'):
#    for file in files:
#        fix_file(os.path.join(root, file))

for root, dirs, files in os.walk('00_SOPORTE'):
    for file in files:
        fix_file(os.path.join(root, file))
