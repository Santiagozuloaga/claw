import os
import re

dirs = ["00_SOPORTE", "01_SRC", "02_TESTS"]
pattern = re.compile(r'(?P<indent>[\t ]*)(?P<keyword>from|import)\s+(?P<module>2026-06-23_CLAW_[A-Za-z0-9_]+)')

def fix_line(line):
    match = pattern.search(line)
    if match:
        indent = match.group('indent')
        keyword = match.group('keyword')
        module = match.group('module')
        
        if keyword == 'import':
            if ' as ' in line:
                parts = line.split(' as ')
                alias = parts[1].strip().split()[0]
                return f'{indent}import importlib; {alias} = importlib.import_module("{module}")\n'
            return f'{indent}import importlib; {module} = importlib.import_module("{module}")\n'
        else: # from
            if ' import ' not in line: return line
            rest = line.split(' import ', 1)[1].strip()
            imports = [i.strip() for i in rest.split(',')]
            fixed = f'{indent}import importlib; _mod = importlib.import_module("{module}"); '
            for imp in imports:
                if ' as ' in imp:
                    name_parts = imp.split(' as ')
                    name = name_parts[0].strip()
                    alias = name_parts[1].strip()
                    fixed += f'{alias} = _mod.{name}; '
                else:
                    fixed += f'{imp} = _mod.{imp}; '
            return fixed + '\n'
    return line

for d in dirs:
    for root, _, files in os.walk(d):
        for f in files:
            if f.endswith('.py'):
                path = os.path.join(root, f)
                with open(path, 'r') as file: lines = file.readlines()
                new_lines = [fix_line(l) for l in lines]
                with open(path, 'w') as file: file.writelines(new_lines)
