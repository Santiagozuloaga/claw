import os
import shutil

for d in ["02_TESTS", "03_DOCS", "04_ASSETS"]:
    if not os.path.exists(d): continue
    for f in os.listdir(d):
        if "_V01_V01" in f:
             path = os.path.join(d, f)
             if os.path.isdir(path): shutil.rmtree(path)
             else: os.remove(path)
