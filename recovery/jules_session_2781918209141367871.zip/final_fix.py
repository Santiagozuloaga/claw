import os
import re

curr = "2026-06-23"

def fix_content(content):
    # Fix module names in imports
    # Pattern: 2024-06-19_CLAW_... or CLAW_2024_06_19_...
    content = re.sub(r'CLAW_2024_06_19_', f'{curr}_CLAW_', content)
    content = re.sub(r'2024-06-19_CLAW_', f'{curr}_CLAW_', content)
    
    # Specific renames
    content = content.replace('CLAWSPRING_CORE', 'CORE')
    content = content.replace('CLAWSPRING_1', 'CORE')
    
    # Fix standard imports to importlib
    # Pattern: from 2026-06-23_CLAW_MOD import ...
    # This regex is specifically for modules starting with date
    pattern = re.compile(r'(?P<indent>[\t ]*)(?P<keyword>from|import)\s+(?P<module>2026-06-23_CLAW_[A-Za-z0-9_]+)')
    
    lines = content.splitlines()
    new_lines = []
    for line in lines:
        match = pattern.search(line)
        if match:
            indent = match.group('indent')
            keyword = match.group('keyword')
            module = match.group('module')
            
            if keyword == 'import':
                if ' as ' in line:
                    parts = line.split(' as ')
                    alias = parts[1].strip().split()[0]
                    new_lines.append(f'{indent}import importlib; {alias} = importlib.import_module("{module}")')
                else:
                    new_lines.append(f'{indent}import importlib; {module} = importlib.import_module("{module}")')
            else: # from
                if ' import ' not in line: 
                    new_lines.append(line)
                    continue
                rest = line.split(' import ', 1)[1].strip()
                imports = [i.strip() for i in rest.split(',')]
                fixed = f'{indent}import importlib; _mod = importlib.import_module("{module}"); '
                for imp in imports:
                    if ' as ' in imp:
                        name_parts = imp.split(' as ')
                        name = name_parts[0].strip()
                        alias = name_parts[1].strip()
                        fixed += f'{alias} = _mod.{name}; '
                    else:
                        fixed += f'{imp} = _mod.{imp}; '
                new_lines.append(fixed)
        else:
            new_lines.append(line)
            
    return '\n'.join(new_lines) + '\n'

for d in ["00_SOPORTE", "01_SRC", "02_TESTS"]:
    for root, _, files in os.walk(d):
        for f in files:
            if f.endswith(".py"):
                path = os.path.join(root, f)
                with open(path, 'r') as file: content = file.read()
                new_content = fix_content(content)
                with open(path, 'w') as file: file.write(new_content)
                print(f"Fixed: {path}")
