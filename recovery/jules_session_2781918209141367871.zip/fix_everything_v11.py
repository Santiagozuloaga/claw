import os
import re

curr = "2026-06-23"

# Fix Imports in all .py files
dirs = ["00_SOPORTE", "01_SRC", "02_TESTS"]

# Pattern to find any imports from 2024 or 2026 or CLAW prefix
pattern = re.compile(r'(?P<indent>[\t ]*)(?P<keyword>from|import)\s+(?P<module>(?:2024-06-19|2026-06-23|CLAW)_CLAW_[A-Za-z0-9_]+)')

def fix_module_name(module):
    # Extract description
    m_desc = re.search(r'CLAW_(.+)', module)
    if m_desc:
        desc = m_desc.group(1)
        # Standardize description: remove any remaining date prefix
        desc = re.sub(r'^\d{4}[-_]\d{2}[-_]\d{2}_', '', desc)
        # Remove any _V01 duplication
        desc = re.sub(r'_V(\d{2})_V(\d{2})$', r'_V\1', desc)
        # Fix specific renames
        if desc == 'CLAWSPRING_CORE' or desc == 'CLAWSPRING_1': desc = 'CORE'
        return f"{curr}_CLAW_{desc}"
    return module

def fix_line(line):
    match = pattern.search(line)
    if match:
        indent = match.group('indent')
        keyword = match.group('keyword')
        module = match.group('module')
        new_module = fix_module_name(module)
        
        if keyword == 'import':
            if ' as ' in line:
                parts = line.split(' as ')
                alias = parts[1].strip().split()[0]
                return f'{indent}import importlib; {alias} = importlib.import_module("{new_module}")\n'
            return f'{indent}import importlib; {new_module} = importlib.import_module("{new_module}")\n'
        else: # from
            if ' import ' not in line: return line
            rest = line.split(' import ', 1)[1].strip()
            imports = [i.strip() for i in rest.split(',')]
            fixed = f'{indent}import importlib; _mod = importlib.import_module("{new_module}"); '
            for imp in imports:
                if ' as ' in imp:
                    name_parts = imp.split(' as ')
                    name = name_parts[0].strip()
                    alias = name_parts[1].strip()
                    fixed += f'{alias} = _mod.{name}; '
                else:
                    fixed += f'{imp} = _mod.{imp}; '
            return fixed + '\n'
    return line

for d in dirs:
    for root, _, files in os.walk(d):
        for f in files:
            if f.endswith('.py'):
                path = os.path.join(root, f)
                with open(path, 'r') as file: lines = file.readlines()
                new_lines = [fix_line(l) for l in lines]
                with open(path, 'w') as file: file.writelines(new_lines)

# Fix run_claw.py
with open("run_claw.py", 'r') as f: content = f.read()
content = re.sub(r'import_module\(".*_CORE_V01"\)', f'import_module("{curr}_CLAW_CORE_V01")', content)
with open("run_claw.py", 'w') as f: f.write(content)
