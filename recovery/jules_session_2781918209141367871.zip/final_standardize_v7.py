import os
import shutil
import re

curr = "2026-06-23"
proj = "CLAW"

def process(d):
    if not os.path.exists(d): return
    for f in os.listdir(d):
        path = os.path.join(d, f)
        if f.startswith(curr): continue
        if f.startswith("."): continue
        
        # Original simple names or already fixed 2024 names
        if f in [".gitignore", "LICENSE", "claw.bat", "config.py", "requirements.txt", "pyproject.toml", "context.py", "cloudsave.py", "compaction.py", "demo.py", "skills.py", "subagent.py", "tool_registry.py", "clawspring (1).py"] or f.startswith("2024-06-19_"):
            desc = f.split('.')[0].upper().replace(' ', '_').replace('(', '').replace(')', '')
            if f.startswith("2024-06-19_"):
                 desc = re.sub(r'^2024-06-19_CLAW_', '', desc)
            if desc == 'CLAWSPRING_CORE' or desc == 'CLAWSPRING_1': desc = 'CORE'
            if f == ".gitignore": desc = "GITIGNORE"
            ext = f.split('.')[-1] if '.' in f else ""
            new_f = f"{curr}_{proj}_{desc}_V01"
            if ext and not f.startswith("2024"): new_f += "." + ext
            elif f.startswith("2024") and "." in f: new_f += "." + f.split('.')[-1]
        elif os.path.isdir(path) and f in ["mcp", "memory", "multi_agent", "plugin", "skill", "task", "voice"]:
            new_f = f"{curr}_{proj}_{f.upper()}_PACKAGE_V01"
        elif f.startswith("test_") and f.endswith(".py"):
            desc = f.split('.')[0].upper()
            new_f = f"{curr}_{proj}_{desc}_V01.py"
        else:
            new_f = f
            
        if new_f != f:
            new_path = os.path.join(d, new_f)
            if os.path.exists(new_path):
                if os.path.isdir(new_path): shutil.rmtree(new_path)
                else: os.remove(new_path)
            os.rename(path, new_path)
            print(f"Renamed: {path} -> {new_path}")

for d in ["00_SOPORTE", "01_SRC", "02_TESTS", "03_DOCS", "04_ASSETS"]:
    process(d)
