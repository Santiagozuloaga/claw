import os
import shutil

dirs = ["00_SOPORTE", "01_SRC", "02_TESTS", "03_DOCS", "04_ASSETS"]

for d in dirs:
    if not os.path.exists(d): continue
    for f in os.listdir(d):
        path = os.path.join(d, f)
        if "_V01_V01" in f:
            if os.path.isdir(path): shutil.rmtree(path)
            else: os.remove(path)
