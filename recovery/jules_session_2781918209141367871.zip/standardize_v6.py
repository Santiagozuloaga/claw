import os
import shutil

curr = "2026-06-23"
proj = "CLAW"

def process(d):
    if not os.path.exists(d): return
    for f in os.listdir(d):
        path = os.path.join(d, f)
        if f.startswith(curr): continue
        if f.startswith("."): continue
        
        desc = f.split('.')[0].upper().replace(' ', '_').replace('(', '').replace(')', '')
        if f.startswith("test_"): desc = f.split('.')[0].upper()
        
        ext = f.split('.')[-1] if '.' in f else ""
        new_f = f"{curr}_{proj}_{desc}_V01"
        if ext: new_f += "." + ext
        
        new_path = os.path.join(d, new_f)
        if os.path.exists(new_path):
            if os.path.isdir(new_path): shutil.rmtree(new_path)
            else: os.remove(new_path)
        os.rename(path, new_path)

for d in ["02_TESTS", "03_DOCS", "04_ASSETS"]:
    process(d)
