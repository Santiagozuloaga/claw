from __future__ import annotations
import sys
import os

# Add 01_SRC to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "01_SRC"))

from 2024-06-19_CLAW_MULTI_AGENT_V01.subagent import SubAgentManager, SubAgentTask

def test_manager_init():
    mgr = SubAgentManager()
    assert mgr is not None

def test_list_tasks_empty():
    mgr = SubAgentManager()
    assert mgr.list_tasks() == []
