from __future__ import annotations
import sys
import os

# Add 01_SRC to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "01_SRC"))

import 2024-06-19_CLAW_SKILL_V01.loader as _loader
from 2024-06-19_CLAW_SKILL_V01.executor import substitute_arguments

def test_load_skills():
    skills = _loader.load_skills()
    assert isinstance(skills, list)

def test_substitute_arguments():
    prompt = "Hello $NAME"
    result = substitute_arguments(prompt, "World", ["NAME"])
    assert "World" in result
