"""
Benchmark script for Ollama models in ClawSpring.
Measures TTFT (Time To First Token) and throughput (tokens/sec).
"""
import time
import sys
import os
import importlib.util
from pathlib import Path

# Add 01_SRC to path
SRC_DIR = Path(__file__).resolve().parent.parent / "01_SRC"
sys.path.append(str(SRC_DIR))

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None: return None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

providers_path = SRC_DIR / "2024-06-19_CLAW_PROVIDERS_V01.py"
if providers_path.exists():
    providers = load_module("providers_optimized", str(providers_path))
else:
    try:
        import 2024-06-19_CLAW_PROVIDERS_V01
    except ImportError:
        print(f"Error: Could not find providers module at {providers_path}")
        sys.exit(1)

def benchmark_model(model_name: str, prompt: str = "Explain quantum entanglement in one paragraph."):
    print(f"\nBenchmarking model: {model_name}")
    
    config = {
        "model": model_name,
        "max_tokens": 512,
        "thinking": False,
    }
    
    system = "You are a helpful assistant."
    messages = [{"role": "user", "content": prompt}]
    
    start_time = time.time()
    ttft = None
    total_tokens = 0
    full_text = ""
    
    try:
        for event in 2024-06-19_CLAW_PROVIDERS_V01.stream(model_name, system, messages, [], config):
            if isinstance(event, 2024-06-19_CLAW_PROVIDERS_V01.TextChunk):
                if ttft is None:
                    ttft = time.time() - start_time
                full_text += event.text
                # Rough token estimation
                total_tokens += len(event.text) / 4
            elif isinstance(event, 2024-06-19_CLAW_PROVIDERS_V01.AssistantTurn):
                # Use actual token counts if available
                if event.out_tokens > 0:
                    total_tokens = event.out_tokens
    except Exception as e:
        print(f"Error benchmarking {model_name}: {e}")
        return None

    end_time = time.time()
    total_time = end_time - start_time
    
    if ttft is None:
        print("No tokens received.")
        return None
        
    tps = total_tokens / (total_time - ttft) if (total_time - ttft) > 0 else 0
    
    results = {
        "model": model_name,
        "ttft": ttft,
        "total_time": total_time,
        "tokens": total_tokens,
        "tps": tps
    }
    
    print(f"  TTFT:         {ttft:.2f}s")
    print(f"  Total Time:   {total_time:.2f}s")
    print(f"  Tokens:       {total_tokens:.1f}")
    print(f"  Throughput:   {tps:.2f} tokens/sec")
    
    return results

def main():
    # Only test local models if Ollama is running
    base_url = "http://localhost:11434"
    
    print(f"Checking Ollama at {base_url}...")
    try:
        models = 2024-06-19_CLAW_PROVIDERS_V01.list_ollama_models(base_url)
    except Exception as e:
        print(f"Ollama server unreachable: {e}")
        models = []
    
    if not models:
        print("Ollama not available; benchmark for local models omitted.")
        return

    test_models = [f"ollama/{m}" for m in models[:3]]

    all_results = []
    for m in test_models:
        res = benchmark_model(m)
        if res:
            all_results.append(res)
            
    if all_results:
        print("\n" + "="*40)
        print(f"{'Model':<20} | {'TTFT':<6} | {'TPS':<6}")
        print("-"*40)
        for r in all_results:
            print(f"{r['model'][:20]:<20} | {r['ttft']:>5.2f}s | {r['tps']:>5.1f}")
        print("="*40)

if __name__ == "__main__":
    main()
