"""Backward-compatibility shim — real implementation is in memory/ package."""
from 2024-06-19_CLAW_MEMORY_PACKAGE_V01.store import (  # noqa: F401
    MemoryEntry,
    save_memory,
    delete_memory,
    load_index,
    search_memory,
    get_index_content,
    parse_frontmatter,
)
from 2024-06-19_CLAW_MEMORY_PACKAGE_V01.context import get_memory_context  # noqa: F401
