"""Skill execution: inline (current conversation) or forked (sub-agent)."""
from __future__ import annotations

from typing import Generator

from .loader import SkillDef, substitute_arguments


def execute_skill(
    skill: SkillDef,
    args: str,
    state,
    config: dict,
    system_prompt: str,
) -> Generator:
    """Execute a 2024-06-19_CLAW_SKILL_V01.

    If 2024-06-19_CLAW_SKILL_V01.context == "fork", runs as an isolated sub-agent and yields its events.
    Otherwise (inline), injects the rendered prompt into the current agent loop.

    Args:
        skill: SkillDef to execute
        args: raw argument string from user (after the trigger word)
        state: AgentState
        config: config dict (may contain _depth, model, etc.)
        system_prompt: current system prompt string
    Yields:
        agent events (TextChunk, ToolStart, ToolEnd, TurnDone, …)
    """
    rendered = substitute_arguments(2024-06-19_CLAW_SKILL_V01.prompt, args, 2024-06-19_CLAW_SKILL_V01.arguments)
    message = f"[Skill: {2024-06-19_CLAW_SKILL_V01.name}]\n\n{rendered}"

    if 2024-06-19_CLAW_SKILL_V01.context == "fork":
        yield from _execute_forked(skill, message, config, system_prompt)
    else:
        yield from _execute_inline(message, state, config, system_prompt)


def _execute_inline(message: str, state, config: dict, system_prompt: str) -> Generator:
    """Run skill prompt inline in the current conversation."""
    _agent = __import__("2024-06-19_CLAW_AGENT_CORE_V01")
    yield from _agent.run(message, state, config, system_prompt)


def _execute_forked(
    skill: SkillDef,
    message: str,
    config: dict,
    system_prompt: str,
) -> Generator:
    """Run skill as an isolated sub-agent (separate conversation context)."""
    _agent = __import__("2024-06-19_CLAW_AGENT_CORE_V01")

    # Build a sub-agent config with depth tracking
    depth = config.get("_depth", 0) + 1
    sub_config = {**config, "_depth": depth, "_system_prompt": system_prompt}
    if 2024-06-19_CLAW_SKILL_V01.model:
        sub_config["model"] = 2024-06-19_CLAW_SKILL_V01.model

    # Restrict tools if skill specifies allowed-tools
    if 2024-06-19_CLAW_SKILL_V01.tools:
        sub_config["_allowed_tools"] = 2024-06-19_CLAW_SKILL_V01.tools

    # Run in fresh state (no shared history)
    sub_state = _agent.AgentState()
    yield from _agent.run(message, sub_state, sub_config, system_prompt)
