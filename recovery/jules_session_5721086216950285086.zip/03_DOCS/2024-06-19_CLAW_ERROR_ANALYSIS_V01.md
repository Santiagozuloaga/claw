# Error: OpenClaw Gateway Starvation
Detected starvation in event-loop (>8s). Connectivity lost.
