#!/usr/bin/env python3
import sys
from pathlib import Path
import importlib.util

project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root / "01_SRC"))

import iso_sage_bootstrap

def start():
    path = project_root / "01_SRC" / "2024-06-19_CLAW_CORE_V01.py"
    spec = importlib.util.spec_from_file_location("core", str(path))
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    core.main()

if __name__ == "__main__":
    start()
