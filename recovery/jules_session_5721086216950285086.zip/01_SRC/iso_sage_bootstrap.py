import importlib.util
import sys
from pathlib import Path

# Prevent multiple executions
if "_ISO_SAGE_BOOTSTRAP_DONE" in globals():
    sys.exit(0)
_ISO_SAGE_BOOTSTRAP_DONE = True

def load_iso(filename, module_name, folder="01_SRC"):
    if module_name in sys.modules:
        return sys.modules[module_name]
    
    root = Path(__file__).parent.parent
    path = root / folder / filename
    if not path.exists():
        return None
        
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception as e:
        # If it fails during exec (maybe due to other missing imports),
        # we keep it in sys.modules but it might be partially initialized.
        pass
    return module

# Registry of core modules
# Order matters if there are circular dependencies
modules = [
    ("2024-06-19_CLAW_CONFIG_V01.py", "config", "00_SOPORTE"),
    ("2024-06-19_CLAW_PROVIDERS_V01.py", "providers", "01_SRC"),
    ("2024-06-19_CLAW_TOOL_REGISTRY_V01.py", "tool_registry", "01_SRC"),
    ("2024-06-19_CLAW_TOOLS_V01.py", "tools", "01_SRC"),
    ("2024-06-19_CLAW_COMPACTION_V01.py", "compaction", "01_SRC"),
    ("2024-06-19_CLAW_CONTEXT_V01.py", "context", "01_SRC"),
    ("2024-06-19_CLAW_AGENT_V01.py", "agent", "01_SRC"),
    ("2024-06-19_CLAW_CLOUDSAVE_V01.py", "cloudsave", "01_SRC"),
    ("2024-06-19_CLAW_MEMORY_SHIM_V01.py", "memory_shim", "01_SRC"),
    ("2024-06-19_CLAW_SKILLS_SHIM_V01.py", "skills_shim", "01_SRC"),
    ("2024-06-19_CLAW_SUBAGENT_SHIM_V01.py", "subagent_shim", "01_SRC"),
    ("2024-06-19_CLAW_CORE_V01.py", "core", "01_SRC"),
]

for fname, mname, fld in modules:
    load_iso(fname, mname, fld)
