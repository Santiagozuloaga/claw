@echo off
REM claw.bat — Lanzador de Claw para Windows
REM Corrección Bug #4: UTF-8 en Windows
REM Doble clic para abrir (Fase 1)

REM Activar UTF-8 en la consola (chcp 65001)
chcp 65001 > nul 2>&1

REM Activar UTF-8 para Python y subprocesos
set PYTHONIOENCODING=utf-8

REM Título de la ventana
title Claw — Asistente IA

REM Directorio del script (para encontrar claw.py)
cd /d "%~dp0"

REM Verificar que Python esté instalado
python --version > nul 2>&1
if errorlevel 1 (
    echo ERROR: Python no encontrado.
    echo Instala Python desde https://python.org
    pause
    exit /b 1
)

REM Activar entorno virtual si existe
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
) else if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
)

REM Iniciar Claw
echo Iniciando Claw...
python claw.py %*

REM Si Claw cierra con error, mostrar pausa
if errorlevel 1 (
    echo.
    echo Claw terminó con error. Revisa los logs.
    pause
)
